document.addEventListener('DOMContentLoaded', () => {
    // Add video handling at the start
    const heroVideo = document.querySelector('.hero-video');
    
    // Function to handle video playback
    const handleVideoPlayback = () => {
        heroVideo.play();
        heroVideo.muted = false;
    };

    // Play video when user interacts with the page
    document.addEventListener('click', handleVideoPlayback, { once: true });
    document.addEventListener('touchstart', handleVideoPlayback, { once: true });

    // Check if video is in viewport and manage playback
    const videoObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                heroVideo.play();
            }
        });
    }, { threshold: 0.1 });

    videoObserver.observe(heroVideo);

    // Dark mode functionality
    const toggleSwitch = document.querySelector('.theme-switch input[type="checkbox"]');
    
    function switchTheme(e) {
        if (e.target.checked) {
            document.documentElement.setAttribute('data-theme', 'dark');
            localStorage.setItem('theme', 'dark');
        } else {
            document.documentElement.setAttribute('data-theme', 'light');
            localStorage.setItem('theme', 'light');
        }    
    }

    toggleSwitch.addEventListener('change', switchTheme);

    // Check for saved theme preference
    const currentTheme = localStorage.getItem('theme');
    if (currentTheme) {
        document.documentElement.setAttribute('data-theme', currentTheme);
        if (currentTheme === 'dark') {
            toggleSwitch.checked = true;
        }
    }

    // Existing contact form handler
    const contactForm = document.getElementById('contactForm');
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        alert('¡Gracias por tu mensaje! Te contactaremos pronto.');
        contactForm.reset();
    });

    // Simplified smooth scroll behavior
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const href = this.getAttribute('href');
            if(href === "#") return;
            
            const target = document.querySelector(href);
            const headerOffset = 80;
            const elementPosition = target.getBoundingClientRect().top;
            const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

            window.scrollTo({
                top: offsetPosition,
                behavior: "smooth"
            });
        });
    });

    // Add intersection observer for section animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: "0px 0px -50px 0px"
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('revealed');
            }
        });
    }, observerOptions);

    document.querySelectorAll('.section').forEach(section => {
        section.classList.add('reveal-section');
        observer.observe(section);
    });

    // Add hover effects for benefit cards
    const beneficioCards = document.querySelectorAll('.beneficio-card');
    beneficioCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-10px)';
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0)';
        });
    });

    // Shopping cart functionality
    let cart = [];
    const cartIcon = document.querySelector('.cart-icon');
    const cartPanel = document.querySelector('.cart-panel');
    const cartItems = document.querySelector('.cart-items');
    const cartTotal = document.querySelector('.cart-total');
    const closeCart = document.querySelector('.close-cart');
    const cartCount = document.querySelector('.cart-count');

    // Toggle cart panel
    cartIcon.addEventListener('click', () => {
        cartPanel.classList.toggle('show-cart');
    });

    closeCart.addEventListener('click', () => {
        cartPanel.classList.remove('show-cart');
    });

    // Product filtering
    const filterButtons = document.querySelectorAll('.filter-btn');
    const productos = document.querySelectorAll('.producto-card');
    const searchInput = document.getElementById('search-product');

    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            const filter = button.dataset.filter;
            filterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            
            productos.forEach(producto => {
                const category = producto.dataset.category;
                if (filter === 'todos' || category === filter) {
                    producto.style.display = 'block';
                } else {
                    producto.style.display = 'none';
                }
            });
        });
    });

    searchInput.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        productos.forEach(producto => {
            const title = producto.querySelector('h3').textContent.toLowerCase();
            if (title.includes(searchTerm)) {
                producto.style.display = 'block';
            } else {
                producto.style.display = 'none';
            }
        });
    });

    // Add to cart functionality
    function updateCart() {
        cartItems.innerHTML = '';
        let total = 0;
        
        cart.forEach((item, index) => {
            total += item.price * item.quantity;
            cartItems.innerHTML += `
                <div class="cart-item">
                    <h4>${item.name}</h4>
                    <div class="cart-item-controls">
                        <button onclick="updateQuantity(${index}, -1)">-</button>
                        <span>${item.quantity}</span>
                        <button onclick="updateQuantity(${index}, 1)">+</button>
                    </div>
                    <p>$${(item.price * item.quantity).toFixed(2)}</p>
                    <button onclick="removeFromCart(${index})" class="remove-item">×</button>
                </div>
            `;
        });

        cartTotal.textContent = `Total: $${total.toFixed(2)}`;
        cartCount.textContent = cart.reduce((sum, item) => sum + item.quantity, 0);
    }

    window.addToCart = function(name, price) {
        const existingItem = cart.find(item => item.name === name);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({ name, price, quantity: 1 });
        }
        updateCart();
    };

    window.updateQuantity = function(index, change) {
        cart[index].quantity = Math.max(0, cart[index].quantity + change);
        if (cart[index].quantity === 0) {
            cart.splice(index, 1);
        }
        updateCart();
    };

    window.removeFromCart = function(index) {
        cart.splice(index, 1);
        updateCart();
    };
});